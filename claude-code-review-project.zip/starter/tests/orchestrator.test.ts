import { beforeEach, describe, expect, it, vi } from 'vitest';

import { query } from '@anthropic-ai/claude-agent-sdk';
import { CodeReviewOrchestrator } from '../src/orchestrator.js';

vi.mock('@anthropic-ai/claude-agent-sdk', () => ({
  query: vi.fn(),
}));

const mockedQuery = vi.mocked(query);

const validReport = {
  pullRequest: {
    owner: 'octocat',
    repo: 'Hello-World',
    number: 1,
  },
  fileReviews: [],
  summary: {
    totalFiles: 0,
    overallScore: 100,
    criticalIssues: 0,
    highPriorityTests: 0,
    refactoringOpportunities: 0,
  },
  recommendations: [],
  metadata: {
    analyzedAt: new Date().toISOString(),
    duration: 10,
    agentVersions: {
      codeQuality: '1.0',
      testCoverage: '1.0',
      refactoring: '1.0',
    },
  },
};

async function* successfulQuery() {
  yield {
    type: 'result',
    subtype: 'success',
    structured_output: validReport,
  };
}

describe('CodeReviewOrchestrator', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('Configuration', () => {
    it('should initialize with default options', () => {
      const orchestrator = new CodeReviewOrchestrator();

      expect(orchestrator).toBeInstanceOf(CodeReviewOrchestrator);
    });

    it('should accept custom configuration options', () => {
      const orchestrator = new CodeReviewOrchestrator({
        model: 'test-model',
        timeoutMs: 30_000,
        maxRetries: 1,
        retryDelayMs: 10,
        estimatedTokens: 2_000,
      });

      expect(orchestrator).toBeInstanceOf(CodeReviewOrchestrator);
    });
  });

  describe('reviewPullRequest', () => {
    it('should reject invalid pull request information', async () => {
      const orchestrator = new CodeReviewOrchestrator();

      await expect(
        orchestrator.reviewPullRequest('', 'Hello-World', 1),
      ).rejects.toThrow('Invalid pull request information.');

      expect(mockedQuery).not.toHaveBeenCalled();
    });

    it('should reject an invalid pull request number', async () => {
      const orchestrator = new CodeReviewOrchestrator();

      await expect(
        orchestrator.reviewPullRequest('octocat', 'Hello-World', 0),
      ).rejects.toThrow('Invalid pull request information.');

      expect(mockedQuery).not.toHaveBeenCalled();
    });

    it('should execute the Claude Agent SDK query successfully', async () => {
      mockedQuery.mockReturnValue(
        successfulQuery() as ReturnType<typeof query>,
      );

      const orchestrator = new CodeReviewOrchestrator({
        model: 'test-model',
      });

      const report = await orchestrator.reviewPullRequest(
        'octocat',
        'Hello-World',
        1,
      );

      expect(report.pullRequest.owner).toBe('octocat');
      expect(report.pullRequest.repo).toBe('Hello-World');
      expect(report.pullRequest.number).toBe(1);
      expect(report.summary.totalFiles).toBe(0);
      expect(mockedQuery).toHaveBeenCalledTimes(1);
    });

    it('should configure Task, MCP servers, all three agents, and structured output', async () => {
      mockedQuery.mockReturnValue(
        successfulQuery() as ReturnType<typeof query>,
      );

      const orchestrator = new CodeReviewOrchestrator({
        model: 'test-model',
      });

      await orchestrator.reviewPullRequest(
        'octocat',
        'Hello-World',
        1,
      );

      const call = mockedQuery.mock.calls[0]?.[0];

      expect(call).toBeDefined();

      if (!call) {
        throw new Error('Expected query to be called.');
      }

      const options = call.options;

      expect(options.allowedTools).toContain('Task');
      expect(options.mcpServers).toHaveProperty('github');
      expect(options.mcpServers).toHaveProperty('eslint');

      expect(options.agents).toHaveProperty('codeQualityAnalyzer');
      expect(options.agents).toHaveProperty('testCoverageAnalyzer');
      expect(options.agents).toHaveProperty('refactoringSuggester');

      expect(options.outputFormat).toMatchObject({
        type: 'json_schema',
      });

      expect(
        (options.outputFormat as { schema: unknown }).schema,
      ).toBeDefined();
    });

    it('should validate the structured output with the ReviewReport schema', async () => {
      mockedQuery.mockReturnValue(
        successfulQuery() as ReturnType<typeof query>,
      );

      const orchestrator = new CodeReviewOrchestrator();

      const report = await orchestrator.reviewPullRequest(
        'octocat',
        'Hello-World',
        1,
      );

      expect(report.pullRequest).toEqual(validReport.pullRequest);
      expect(report.fileReviews).toEqual([]);
      expect(report.summary).toEqual(validReport.summary);
      expect(report.recommendations).toEqual(validReport.recommendations);

      expect(report.metadata.analyzedAt).toBeDefined();
      expect(typeof report.metadata.analyzedAt).toBe('string');
      expect(typeof report.metadata.duration).toBe('number');
      expect(report.metadata.agentVersions).toEqual(
  validReport.metadata.agentVersions,

);
    });

    it('should reject invalid structured output', async () => {
      async function* invalidQuery() {
        yield {
          type: 'result',
          subtype: 'success',
          structured_output: {
            invalid: true,
          },
        };
      }

      mockedQuery.mockReturnValue(
        invalidQuery() as ReturnType<typeof query>,
      );

      const orchestrator = new CodeReviewOrchestrator();

      await expect(
        orchestrator.reviewPullRequest(
          'octocat',
          'Hello-World',
          1,
        ),
      ).rejects.toThrow('Operation failed after 2 attempts');
    });
  });

  describe('Integration', () => {
    it.skip('should review a real public PR', async () => {
      // Requires live Anthropic and GitHub credentials.
      // Run manually when real integration testing is required.
    });
  });
});
