---
description: Security-focused code review guidance covering OWASP risks, authentication, authorization, input validation, secrets, and secure data handling.
---

# Security Analysis

Use this skill when reviewing code for security vulnerabilities and unsafe practices.

## Authentication

Check for:

- Weak authentication mechanisms
- Missing authentication checks
- Improper session handling
- Hardcoded credentials
- Exposed API keys or tokens
- Insecure password handling

## Authorization

Check whether:

- Sensitive operations require authorization
- Users can access resources belonging to other users
- Privilege boundaries are enforced
- Role checks are applied consistently
- Authorization is performed on the server side

## Input Validation

Look for:

- Missing input validation
- Trusting client-controlled values
- Unsafe file paths
- Unvalidated URLs
- Unexpected data types
- Missing size or length limits

Validate input at trust boundaries.

## Injection Risks

Check for:

- SQL injection
- NoSQL injection
- Command injection
- Cross-site scripting
- Template injection
- Unsafe dynamic evaluation
- Unsafe shell command construction

Prefer parameterized queries and safe APIs over string concatenation.

## Secrets and Sensitive Data

Look for:

- API keys in source code
- Passwords or tokens in logs
- Credentials committed to repositories
- Sensitive data exposed in error messages
- Personal or confidential information unnecessarily returned by APIs

Secrets should be stored securely in environment variables or a dedicated secret-management system.

## Data Handling

Review:

- Encryption of sensitive data
- HTTPS/TLS usage
- Secure cookie configuration
- Sensitive information in URLs
- Excessive API responses
- Unsafe serialization and deserialization

## OWASP-Focused Review

Pay particular attention to:

- Broken access control
- Cryptographic failures
- Injection
- Insecure design
- Security misconfiguration
- Vulnerable or outdated components
- Identification and authentication failures
- Software and data integrity failures
- Security logging and monitoring failures
- Server-side request forgery

## Severity Guidance

- Critical: Vulnerabilities that can lead to severe compromise, unauthorized access, or sensitive-data exposure
- High: Significant exploitable security weaknesses
- Medium: Security weaknesses requiring specific conditions or reducing defense-in-depth
- Low: Minor security-hardening opportunities

## Output

For each significant security finding provide:

- File and location
- Severity
- Vulnerability category
- Explanation
- Evidence
- Security impact
- Recommended remediation
