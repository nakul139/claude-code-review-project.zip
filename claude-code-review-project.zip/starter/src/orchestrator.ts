import { query } from '@anthropic-ai/claude-agent-sdk';
import { zodToJsonSchema } from 'zod-to-json-schema';

import type { ReviewReport } from './types/report-types.js';
import {
  ReviewReportSchema,
  ReviewReportJSONSchema,
} from './types/report-types.js';

import { mcpServersConfig } from './config/mcp.config.js';

import {
  codeQualityAnalyzer,
  testCoverageAnalyzer,
  refactoringSuggester,
} from './agents/index.js';

import { buildOrchestratorPrompt } from './prompts/orchestrator.prompt.js';

import {
  ErrorCodes,
  ReviewError,
  withRetry,
  withTimeout,
} from './utils/error-handler.js';

import {
  globalRateLimiter,
  withRateLimit,
} from './utils/rate-limiter.js';

export interface OrchestratorOptions {
  model?: string;
  cwd?: string;
  timeoutMs?: number;
  maxRetries?: number;
  retryDelayMs?: number;
  estimatedTokens?: number;
}

export class CodeReviewOrchestrator {
  private readonly options: OrchestratorOptions;

  constructor(options: OrchestratorOptions = {}) {
    this.options = options;
  }

  /**
   * Review a pull request using the three specialized subagents.
   */
  async reviewPullRequest(
    owner: string,
    repo: string,
    prNumber: number
  ): Promise<ReviewReport> {
    if (
      !owner ||
      !repo ||
      !Number.isInteger(prNumber) ||
      prNumber <= 0
    ) {
      throw new ReviewError(
        'Invalid pull request information.',
        ErrorCodes.VALIDATION_FAILED,
        {
          owner,
          repo,
          prNumber,
        }
      );
    }

    const prompt = buildOrchestratorPrompt(
      owner,
      repo,
      prNumber
    );

    const timeoutMs = this.options.timeoutMs ?? 180_000;
    const maxRetries = this.options.maxRetries ?? 2;
    const retryDelayMs = this.options.retryDelayMs ?? 500;
    const estimatedTokens =
      this.options.estimatedTokens ?? 8_000;

    return withRateLimit(
      globalRateLimiter,
      () =>
        withRetry(
          () =>
            withTimeout(
              () => this.executeQuery(prompt),
              timeoutMs,
              `Code review exceeded the ${timeoutMs}ms timeout.`
            ),
          maxRetries,
          retryDelayMs
        ),
      estimatedTokens
    );
  }

  /**
   * Execute the Claude Agent SDK query.
   */
  private async executeQuery(
    prompt: string
  ): Promise<ReviewReport> {
    const startTime = Date.now();

    const queryResult = query({
      prompt,

      options: {
        model:
          this.options.model ??
          process.env.ANTHROPIC_MODEL ??
          'claude-sonnet-4-5-20250929',

        cwd:
          this.options.cwd ??
          process.env.PROJECT_ROOT ??
          process.cwd(),

        mcpServers: mcpServersConfig,

        agents: {
          codeQualityAnalyzer,
          testCoverageAnalyzer,
          refactoringSuggester,
        },

        allowedTools: [
          'Task',

          'mcp__github__get_pull_request',
          'mcp__github__get_pull_request_files',
          'mcp__github__get_file_contents',

          'mcp__eslint__lint-files',

          'Skill',
        ],

        outputFormat: {
          type: 'json_schema',
          schema: ReviewReportJSONSchema,
        },
      },
    });

    let finalReport: ReviewReport | undefined;

    try {
      for await (const message of queryResult) {
        if (
          message.type === 'result' &&
          message.subtype === 'success' &&
          message.structured_output
        ) {
          const validation =
            ReviewReportSchema.safeParse(
              message.structured_output
            );

          if (!validation.success) {
            throw new ReviewError(
              'Structured review output failed schema validation.',
              ErrorCodes.STRUCTURED_OUTPUT_FAILED,
              {
                issues: validation.error.issues,
              }
            );
          }

          finalReport = validation.data;
        }

        if (
          message.type === 'result' &&
          message.subtype !== 'success'
        ) {
          throw new ReviewError(
            `Code review failed: ${message.subtype}`,
            ErrorCodes.AGENT_FAILED,
            {
              subtype: message.subtype,
            }
          );
        }
      }
    } catch (error) {
      if (error instanceof ReviewError) {
        throw error;
      }

      throw new ReviewError(
        error instanceof Error
          ? error.message
          : String(error),
        ErrorCodes.AGENT_FAILED
      );
    }

    if (!finalReport) {
      throw new ReviewError(
        'Code review completed without a valid structured report.',
        ErrorCodes.STRUCTURED_OUTPUT_FAILED
      );
    }

    const result: ReviewReport = {
      ...finalReport,

      metadata: {
        ...finalReport.metadata,
        analyzedAt: new Date().toISOString(),
        duration: Date.now() - startTime,
      },
    };

    const finalValidation =
      ReviewReportSchema.safeParse(result);

    if (!finalValidation.success) {
      throw new ReviewError(
        'Final review report failed schema validation.',
        ErrorCodes.STRUCTURED_OUTPUT_FAILED,
        {
          issues: finalValidation.error.issues,
        }
      );
    }

    return finalValidation.data;
  }
}