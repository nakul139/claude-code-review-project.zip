import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { buildRefactoringPrompt } from '../prompts/refactoring-suggester.prompt.js';

export const refactoringSuggester: AgentDefinition = {
  description:
    'Analyzes pull request changes and identifies refactoring opportunities that improve readability, maintainability, structure, and long-term code quality.',

  prompt: buildRefactoringPrompt(),

  model: 'inherit',

  tools: [
    'mcp__github__get_pull_request',
    'mcp__github__get_pull_request_files',
    'mcp__github__get_file_contents',
  ],
};