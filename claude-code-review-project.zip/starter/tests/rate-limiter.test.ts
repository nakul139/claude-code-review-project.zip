import { describe, expect, it } from 'vitest';

import { RateLimiter } from '../src/utils/rate-limiter.js';

describe('RateLimiter', () => {
  it('should allow a request when under the limits', () => {
    const limiter = new RateLimiter({
      maxRequestsPerMinute: 10,
      maxTokensPerMinute: 10_000,
      maxConcurrent: 2,
    });

    expect(limiter.canProceed(1_000)).toBe(true);
  });

  it('should block requests when the concurrent limit is reached', async () => {
    const limiter = new RateLimiter({
      maxRequestsPerMinute: 10,
      maxTokensPerMinute: 10_000,
      maxConcurrent: 1,
    });

    await limiter.acquire(1_000);

    expect(limiter.canProceed(1_000)).toBe(false);

    limiter.release(1_000);

    expect(limiter.canProceed(1_000)).toBe(true);
  });

  it('should block requests when the token limit is exceeded', async () => {
    const limiter = new RateLimiter({
      maxRequestsPerMinute: 10,
      maxTokensPerMinute: 1_000,
      maxConcurrent: 2,
    });

    await limiter.acquire(900);

    expect(limiter.canProceed(200)).toBe(false);

    limiter.release(900);

    expect(limiter.canProceed(200)).toBe(false);
  });

  it('should block requests when the request-per-minute limit is reached', async () => {
    const limiter = new RateLimiter({
      maxRequestsPerMinute: 2,
      maxTokensPerMinute: 10_000,
      maxConcurrent: 5,
    });

    await limiter.acquire(100);
    limiter.release(100);

    await limiter.acquire(100);
    limiter.release(100);

    expect(limiter.canProceed(100)).toBe(false);
  });

  it('should allow requests after old records are pruned', async () => {
    const limiter = new RateLimiter({
      maxRequestsPerMinute: 1,
      maxTokensPerMinute: 10_000,
      maxConcurrent: 2,
    });

    await limiter.acquire(100);
    limiter.release(100);

    expect(limiter.canProceed(100)).toBe(false);

    // Wait slightly longer than the one-minute window.
    await new Promise((resolve) => setTimeout(resolve, 100));

    // The request is still inside the one-minute window, so it should remain blocked.
    expect(limiter.canProceed(100)).toBe(false);
  });
});
