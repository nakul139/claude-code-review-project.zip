import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { buildTestCoveragePrompt } from '../prompts/test-coverage-analyzer.prompt.js';

export const testCoverageAnalyzer: AgentDefinition = {
  description:
    'Analyzes pull request changes for test coverage, test quality, missing test cases, and potential regressions.',

  prompt: buildTestCoveragePrompt(),

  model: 'inherit',

  tools: [
    'mcp__github__get_pull_request',
    'mcp__github__get_pull_request_files',
    'mcp__github__get_file_contents',
  ],
};