import 'dotenv/config';
import { mkdir, writeFile } from 'node:fs/promises';

import { CodeReviewOrchestrator } from './orchestrator.js';
import { ReportGenerator } from './utils/report-generator.js';

/**
 * Parse and validate command-line arguments.
 */
function parseArgs(): {
  owner: string;
  repo: string;
  prNumber: number;
} {
  const [owner, repo, prStr] = process.argv.slice(2);

  if (!owner || !repo || !prStr) {
    throw new Error(
      'Usage: npm run dev -- <owner> <repo> <pr-number>'
    );
  }

  const prNumber = Number(prStr);

  if (!Number.isInteger(prNumber) || prNumber <= 0) {
    throw new Error(
      'PR number must be a positive integer. Example: npm run dev -- octocat Hello-World 1'
    );
  }

  return {
    owner,
    repo,
    prNumber,
  };
}

/**
 * Validate authentication and required environment variables.
 */
function validateEnv(): {
  model: string;
  projectRoot: string;
} {
  const hasAnthropicApiKey = Boolean(
    process.env.ANTHROPIC_API_KEY
  );

  const hasAwsCredentials =
    Boolean(process.env.AWS_ACCESS_KEY_ID) &&
    Boolean(process.env.AWS_SECRET_ACCESS_KEY);

  if (!hasAnthropicApiKey && !hasAwsCredentials) {
    throw new Error(
      'Missing authentication: set ANTHROPIC_API_KEY or AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY.'
    );
  }

  if (hasAnthropicApiKey) {
    console.log(
      '🔐 Using Anthropic API authentication'
    );
  } else {
    if (!process.env.AWS_REGION) {
      throw new Error(
        'AWS_REGION is required when using AWS Bedrock authentication.'
      );
    }

    console.log(
      '🔐 Using AWS Bedrock authentication'
    );
  }

  const model = process.env.ANTHROPIC_MODEL;

  if (!model) {
    throw new Error(
      'ANTHROPIC_MODEL environment variable is required.'
    );
  }

  /*
   * PROJECT_ROOT is optional. If it is not provided,
   * use the current project directory.
   */
  const projectRoot =
    process.env.PROJECT_ROOT || process.cwd();

  return {
    model,
    projectRoot,
  };
}

/**
 * Main entry point.
 */
async function main(): Promise<void> {
  try {
    const { owner, repo, prNumber } = parseArgs();

    const {
      model,
      projectRoot,
    } = validateEnv();

    console.log(
      `🔍 Reviewing ${owner}/${repo} PR #${prNumber}...`
    );

    const orchestrator =
      new CodeReviewOrchestrator({
        model,
        cwd: projectRoot,
      });

    const report =
      await orchestrator.reviewPullRequest(
        owner,
        repo,
        prNumber
      );

    const reportGenerator =
      new ReportGenerator();

    const markdownReport =
      reportGenerator.generateMarkdownReport(
        report
      );

    const htmlReport =
      reportGenerator.generateHTMLReport(
        report
      );

    const jsonReport =
      reportGenerator.generateJSONReport(
        report
      );

    await mkdir('reports', {
      recursive: true,
    });

    const baseName =
      `${owner}_${repo}_${prNumber}`;

    await Promise.all([
      writeFile(
        `reports/${baseName}.md`,
        markdownReport,
        'utf-8'
      ),

      writeFile(
        `reports/${baseName}.html`,
        htmlReport,
        'utf-8'
      ),

      writeFile(
        `reports/${baseName}.json`,
        jsonReport,
        'utf-8'
      ),
    ]);

    console.log(
      '✅ Code review completed successfully.'
    );

    console.log(
      `📄 reports/${baseName}.md`
    );

    console.log(
      `🌐 reports/${baseName}.html`
    );

    console.log(
      `📦 reports/${baseName}.json`
    );
  } catch (error) {
    console.error(
      '❌ Code review failed:',
      error instanceof Error
        ? error.message
        : String(error)
    );

    process.exitCode = 1;
  }
}

main().catch((error: unknown) => {
  console.error(
    '❌ Unexpected error:',
    error instanceof Error
      ? error.message
      : String(error)
  );

  process.exitCode = 1;
});