# Claude Skills

This directory contains Claude Skills - reusable domain expertise that agents can invoke.

## What Are Skills?

Skills are markdown files that provide Claude with specialized knowledge for specific tasks. They're loaded automatically by the Claude Agent SDK when agents invoke them.

## Available Skills

### JavaScript Best Practices

`javascript-best-practices/SKILL.md`

Provides guidance for JavaScript code review, including best practices, common pitfalls, and maintainability.

### TypeScript Patterns

`typescript-patterns/SKILL.md`

Provides TypeScript-specific analysis covering:

- Type safety
- Advanced TypeScript patterns
- Interfaces and type aliases
- Generics
- Async patterns
- TypeScript architecture
- Common type issues

### Security Analysis

`security-analysis/SKILL.md`

Provides security-focused code review guidance covering:

- OWASP risks
- Authentication and authorization
- Input validation
- Injection vulnerabilities
- Secrets and sensitive data
- Secure data handling

## Skill File Structure

Each skill is stored in its own folder with a `SKILL.md` file:

```text
.claude/skills/
├── javascript-best-practices/
│   └── SKILL.md
├── typescript-patterns/
│   └── SKILL.md
└── security-analysis/
    └── SKILL.md
