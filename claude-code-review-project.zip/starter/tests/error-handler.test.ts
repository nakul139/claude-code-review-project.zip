import { describe, expect, it, vi } from 'vitest';

import { withRetry, withTimeout } from '../src/utils/error-handler.js';

describe('Error Handler Utilities', () => {
  it('should return the result when the operation succeeds', async () => {
    const operation = vi.fn().mockResolvedValue('success');

    const result = await withRetry(operation, 3, 1);

    expect(result).toBe('success');
    expect(operation).toHaveBeenCalledTimes(1);
  });

  it('should retry a failed operation and eventually succeed', async () => {
    const operation = vi
      .fn()
      .mockRejectedValueOnce(new Error('temporary failure'))
      .mockRejectedValueOnce(new Error('temporary failure'))
      .mockResolvedValue('success');

    const result = await withRetry(operation, 3, 1);

    expect(result).toBe('success');
    expect(operation).toHaveBeenCalledTimes(3);
  });

  it('should throw after all retry attempts are exhausted', async () => {
    const operation = vi.fn().mockRejectedValue(new Error('permanent failure'));

    await expect(withRetry(operation, 3, 1)).rejects.toThrow(
      'Operation failed after 3 attempts'
    );

    expect(operation).toHaveBeenCalledTimes(3);
  });

  it('should return before the timeout when the operation is fast enough', async () => {
    const operation = vi.fn().mockResolvedValue('completed');

    const result = await withTimeout(operation, 100);

    expect(result).toBe('completed');
  });

  it('should reject when the operation exceeds the timeout', async () => {
    const operation = vi.fn(
      () =>
        new Promise<string>((resolve) => {
          setTimeout(() => resolve('too late'), 100);
        })
    );

    await expect(
      withTimeout(operation, 10, 'Test operation timed out')
    ).rejects.toThrow('Test operation timed out');
  });
});
