import { describe, expect, it } from 'vitest';

import {
  ReviewReportSchema,
  ReviewReportJSONSchema,
} from '../src/types/report-types.js';

const validReport = {
  pullRequest: {
    owner: 'octocat',
    repo: 'Hello-World',
    number: 1,
  },

  fileReviews: [],

  summary: {
    totalFiles: 0,
    overallScore: 100,
    criticalIssues: 0,
    highPriorityTests: 0,
    refactoringOpportunities: 0,
  },

  recommendations: [],

  metadata: {
    analyzedAt: new Date().toISOString(),
    duration: 100,
    agentVersions: {
      codeQuality: '1.0',
      testCoverage: '1.0',
      refactoring: '1.0',
    },
  },
};

describe('ReviewReportSchema', () => {
  it('should accept a valid review report', () => {
    const result =
      ReviewReportSchema.safeParse(validReport);

    expect(result.success).toBe(true);
  });

  it('should reject an invalid pull request number', () => {
    const invalidReport = {
      ...validReport,
      pullRequest: {
        ...validReport.pullRequest,
        number: '1',
      },
    };

    const result =
      ReviewReportSchema.safeParse(invalidReport);

    expect(result.success).toBe(false);
  });

  it('should reject an invalid recommendation priority', () => {
    const invalidReport = {
      ...validReport,
      recommendations: [
        {
          priority: 'urgent',
          category: 'security',
          description: 'Security issue',
          files: ['src/app.ts'],
        },
      ],
    };

    const result =
      ReviewReportSchema.safeParse(invalidReport);

    expect(result.success).toBe(false);
  });

  it('should handle an empty report correctly', () => {
    const result =
      ReviewReportSchema.safeParse(validReport);

    expect(result.success).toBe(true);

    if (result.success) {
      expect(result.data.fileReviews).toHaveLength(0);
      expect(result.data.recommendations).toHaveLength(0);
      expect(result.data.summary.totalFiles).toBe(0);
    }
  });

  it('should export a JSON schema', () => {
    expect(ReviewReportJSONSchema).toBeDefined();
    expect(typeof ReviewReportJSONSchema).toBe('object');
  });
});