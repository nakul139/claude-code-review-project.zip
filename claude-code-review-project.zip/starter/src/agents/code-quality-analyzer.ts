import type { AgentDefinition } from '@anthropic-ai/claude-agent-sdk';
import { buildCodeQualityPrompt } from '../prompts/code-quality-analyzer.prompt.js';

export const codeQualityAnalyzer: AgentDefinition = {
  description:
    'Analyzes pull request code for quality, correctness, maintainability, security, and TypeScript/JavaScript best practices.',

  prompt: buildCodeQualityPrompt(),

  model: 'inherit',

  tools: [
    'mcp__github__get_pull_request',
    'mcp__github__get_pull_request_files',
    'mcp__github__get_file_contents',
    'mcp__eslint__lint-files',
    'Skill',
  ],
};