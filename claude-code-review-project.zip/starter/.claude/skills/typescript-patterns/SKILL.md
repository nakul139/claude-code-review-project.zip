---
description: TypeScript-specific code review guidance covering type safety, advanced patterns, async code, and maintainable TypeScript design.
---

# TypeScript Patterns

Use this skill when reviewing TypeScript code.

## Type Safety

Check for:

- Unnecessary use of `any`
- Unsafe type assertions
- Missing or overly broad types
- Incorrect nullable or optional handling
- Weak function parameter and return types
- Type definitions that do not match runtime behavior
- Opportunities to use discriminated unions

Prefer precise types over `any`.

## Interfaces and Type Aliases

Review whether:

- Interfaces and type aliases are used consistently
- Types accurately model the domain
- Shared types are reused instead of duplicated
- Types are kept small and focused

Avoid unnecessarily complex type definitions.

## Generics

Check generic code for:

- Meaningful type parameters
- Appropriate constraints
- Avoiding unnecessary generic complexity
- Preserving type information through functions and APIs

## Async and Promise Patterns

Check for:

- Correct `async`/`await` usage
- Missing error handling
- Unhandled promises
- Incorrect Promise chains
- Race conditions
- Unnecessary sequential awaits where safe parallelism is possible

## Classes and Architecture

Review:

- Separation of responsibilities
- Encapsulation
- Dependency handling
- Appropriate access modifiers
- Avoidance of overly large classes or methods

## Common Problems

Look for:

- `any` hiding real type errors
- Non-null assertions used without justification
- Type assertions masking incompatible values
- Inconsistent API response types
- Duplicated type definitions
- Complex types that reduce readability

## Severity Guidance

- Critical: Type problems that can cause severe runtime failures or security-sensitive incorrect behavior
- High: Type issues likely to cause significant bugs
- Medium: Maintainability or correctness concerns
- Low: Minor type clarity or consistency improvements

## Output

For each significant finding provide:

- File and location
- Severity
- Explanation
- Evidence
- Recommended improvement
